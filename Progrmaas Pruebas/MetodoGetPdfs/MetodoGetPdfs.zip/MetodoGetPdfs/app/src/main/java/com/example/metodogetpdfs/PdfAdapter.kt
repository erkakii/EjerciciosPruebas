package com.example.metodogetpdfs

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PdfAdapter(private val pdfList: List<Pdf>, private val onItemClickListener: (Pdf) -> Unit) : RecyclerView.Adapter<PdfAdapter.PdfViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PdfViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.pdf_item, parent, false)
        return PdfViewHolder(view)
    }

    override fun getItemCount() = pdfList.size

    override fun onBindViewHolder(holder: PdfViewHolder, position: Int) {
        val pdf = pdfList[position]
        holder.bind(pdf)
        holder.itemView.setOnClickListener { onItemClickListener(pdf) }
    }

    class PdfViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val tvTitle: TextView = itemView.findViewById(R.id.tvPdfTitle)

        fun bind(pdf: Pdf) {
            tvTitle.text = pdf.titulo
        }
    }
}
